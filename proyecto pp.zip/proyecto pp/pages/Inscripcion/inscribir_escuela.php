<?php
include './conexion.php'; // Conectar a la base de datos

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Obtener los datos del formulario
    $escuela = $_POST['escuela'];
    $horario = $_POST['horario'];

    // Preparar la consulta SQL
    $stmt = $conexion->prepare("INSERT INTO inscripciones (escuela, horario) VALUES (?, ?)");
    
    // Vincular parámetros
    $stmt->bind_param("ss", $escuela, $horario);

    // Ejecutar la consulta
    if ($stmt->execute()) {
        echo "Inscripción guardada exitosamente.";
    } else {
        echo "Error al guardar la inscripción: " . $stmt->error;
    }

    // Cerrar la declaración y la conexión
    $stmt->close();
    $conexion->close();
} else {
    echo "Método de solicitud no válido.";
}
?>