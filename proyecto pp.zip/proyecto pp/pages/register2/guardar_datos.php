<?php
include '../conexion.php'; // Conectar a la base de datos

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Obtener los datos del formulario
    $tipo_identificacion = $_POST['tipo_identificacion'];
    $pais_emisor = $_POST['pais_emisor'];
    $numero_cuil = $_POST['numero_cuil'];
    $fecha_nacimiento = $_POST['fecha_nacimiento'];
    $nacionalidad = $_POST['nacionalidad'];
    $codigo_pais = $_POST['codigo_pais'];
    $codigo_area = $_POST['codigo_area'];
    $numero = $_POST['numero'];

    // Preparar la consulta SQL
    $stmt = $conexion->prepare("INSERT INTO usuarios (tipo_identificacion, pais_emisor, numero_cuil, fecha_nacimiento, nacionalidad, nombre, apellido, codigo_pais, codigo_area, numero) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    
    // Vincular parámetros
    $stmt->bind_param("sssssssssss", $tipo_identificacion, $pais_emisor, $numero_cuil, $fecha_nacimiento, $nacionalidad, $nombre, $apellido, $codigo_pais, $codigo_area, $numero);

    // Ejecutar la consulta
    if ($stmt->execute()) {
        echo "Registro guardado exitosamente.";
    } else {
        echo "Error al guardar el registro: " . $stmt->error;
    }

    // Cerrar la declaración y la conexión
    $stmt->close();
    $conexion->close();
} else {
    echo "Método de solicitud no válido.";
}
?>