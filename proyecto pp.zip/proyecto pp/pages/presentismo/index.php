<?php
include '../../conexion.php'; // Asegúrate de que la ruta sea correcta

// Obtener alumnos
$stmt = $conexion->query("SELECT * FROM alumnos");
$alumnos = $stmt->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="http://localhost/proyecto%20pp/pages/presentismo/style.css">
    <title>Lista de Alumnos - Presentismo</title>
</head>
<body>
    <h1>Lista de Alumnos</h1>
    <form action="agregar.php" method="POST">
        <input type="text" name="nombre" placeholder="Nombre del Alumno" required>
        <input type="date" name="fecha" required>
        <button type="submit">Agregar Alumno</button>
    </form>

    <table>
    <thead>
        <tr>
            <th>ID</th>
            <th>Nombre</th>
            <th>Fecha</th>
            <th>Estado</th>
            <th>Acciones</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($alumnos as $alumno): ?>
            <tr>
                <td><?php echo $alumno['id']; ?></td>
                <td><?php echo $alumno['nombre']; ?></td>
                <td><?php echo $alumno['fecha']; ?></td>
                <td><?php echo $alumno['estado']; ?></td> 
                <td>
                    <a href="editar.php?id=<?php echo $alumno['id']; ?>">Editar</a>
                    <a href="eliminar.php?id=<?php echo $alumno['id']; ?>">Eliminar</a>
                    <form action="cambiar_estado.php" method="POST" style="display:inline;">
                        <input type="hidden" name="id" value="<?php echo $alumno['id']; ?>">
                        <select name="estado">
                            <option value="presente" <?php echo $alumno['estado'] == 'presente' ? 'selected' : ''; ?>>Presente</option>
                            <option value="ausente" <?php echo $alumno['estado'] == 'ausente' ? 'selected' : ''; ?>>Ausente</option>
                        </select>
                        <button type="submit">Cambiar</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>
</body>
</html>