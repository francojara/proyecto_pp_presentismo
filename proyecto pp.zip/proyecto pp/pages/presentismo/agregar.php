<?php
include '../../conexion.php'; // Asegúrate de que la ruta sea correcta

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nombre = $_POST['nombre'];
    $fecha = $_POST['fecha'];

    // Cambia $pdo por $conexion si estás usando mysqli
    $stmt = $conexion->prepare("INSERT INTO alumnos (nombre, fecha) VALUES (?, ?)");
    $stmt->bind_param("ss", $nombre, $fecha); // Vincula los parámetros
    $stmt->execute();

    header("Location: index.php");
}
?>