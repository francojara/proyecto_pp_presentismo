<?php
include '../../conexion.php';

$id = $_GET['id'];

// Prepara la consulta
$stmt = $conexion->prepare("DELETE FROM alumnos WHERE id = ?");

// Vincula el parámetro
$stmt->bind_param("i", $id); // "i" indica que el tipo es un entero

// Ejecuta la consulta
$stmt->execute();

// Redirige a index.php
header("Location: index.php");
?>