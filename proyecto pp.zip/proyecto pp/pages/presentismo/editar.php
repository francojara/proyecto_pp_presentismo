<?php
include '../../conexion.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'];
    $nombre = $_POST['nombre'];
    $fecha = $_POST['fecha'];

    // Prepara la consulta
    $stmt = $conexion->prepare("UPDATE alumnos SET nombre = ?, fecha = ? WHERE id = ?");
    
    // Vincula los parámetros
    $stmt->bind_param("ssi", $nombre, $fecha, $id); // "ssi" indica que los tipos son: string, string, integer

    // Ejecuta la consulta
    $stmt->execute();

    header("Location: index.php");
} else {
    $id = $_GET['id'];
    $stmt = $conexion->prepare("SELECT * FROM alumnos WHERE id = ?");
    $stmt->bind_param("i", $id); // Vincula el parámetro id como entero
    $stmt->execute();
    $result = $stmt->get_result();
    $alumno = $result->fetch_assoc();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Editar Alumno</title>
</head>
<body>
    <h1>Editar Alumno</h1>
    <form action="editar.php" method="POST">
        <input type="hidden" name="id" value="<?php echo $alumno['id']; ?>">
        <input type="text" name="nombre" value="<?php echo $alumno['nombre']; ?>" required>
        <input type="date" name="fecha" value="<?php echo $alumno['fecha']; ?>" required>
        <button type="submit">Actualizar Alumno</button>
    </form>
</body>
</html>