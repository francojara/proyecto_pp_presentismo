<?php
include '../../conexion.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'];
    $estado = $_POST['estado'];

    // Prepara la consulta
    $stmt = $conexion->prepare("UPDATE alumnos SET estado = ? WHERE id = ?");
    $stmt->bind_param("si", $estado, $id); // "si" indica que el primer parámetro es un string y el segundo es un entero

    // Ejecuta la consulta
    $stmt->execute();

    header("Location: index.php");
} else {
    echo "Método de solicitud no válido.";
}
?>