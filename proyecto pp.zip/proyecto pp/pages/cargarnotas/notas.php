<?php
include '../conexion.php'; // Conectar a la base de datos

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $course = $_POST['course'];
    $student = $_POST['student'];
    $grade = $_POST['grade'];

    // Guardar la nota en la base de datos
    $stmt = $