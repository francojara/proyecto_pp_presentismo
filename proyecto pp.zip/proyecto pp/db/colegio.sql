CREATE DATABASE IF NOT EXISTS colegio;

USE colegio;

-- Tabla Identificacion

CREATE TABLE Identificacion (

    id_identificacion INT AUTO_INCREMENT PRIMARY KEY,

    nombre_identificacion VARCHAR(100) NOT NULL

);


-- Tabla usuario

CREATE TABLE usuario (

    id INT AUTO_INCREMENT PRIMARY KEY,

    tipo_identificacion VARCHAR(50),

    nombre VARCHAR(100) NOT NULL,

    apellido VARCHAR(100) NOT NULL,

    fecha_nacimiento DATE NOT NULL,

    año_inscripcion INT(4) NOT NULL,

    email VARCHAR(100) NOT NULL UNIQUE,
    
    contraseña VARCHAR(100) NOT NULL,

    telefono VARCHAR(20) NOT NULL,

    numero_cuil VARCHAR(20) NOT NULL,

    pais INT(20) NOT NULL,

    Identificacion INT(20) NOT NULL,

    FOREIGN KEY (pais) REFERENCES Pais(id_Pais),

    FOREIGN KEY (identificacion) REFERENCES Identificacion(id_identificacion)

);



-- Tabla Materias

CREATE TABLE Materias (

    id INT AUTO_INCREMENT PRIMARY KEY,

    nombre VARCHAR(100) NOT NULL

);


-- Tabla Clases

CREATE TABLE Clases (

    id INT AUTO_INCREMENT PRIMARY KEY,

    materia_id INT NOT NULL,

    dia VARCHAR(10) NOT NULL,

    hora_inicio TIME NOT NULL,

    hora_fin TIME NOT NULL,

    aula VARCHAR(50) NOT NULL,

    FOREIGN KEY (materia_id) REFERENCES Materias(id)

);


-- Tabla Notas

CREATE TABLE Notas (

    id INT AUTO_INCREMENT PRIMARY KEY,

    usuario_id INT NOT NULL,

    materia_id INT NOT NULL,

    nota DECIMAL(9, 1) NOT NULL,

    FOREIGN KEY (usuario_id) REFERENCES usuario(id),

    FOREIGN KEY (materia_id) REFERENCES Materias(id)

);


-- Tabla Faltas

CREATE TABLE Faltas (

    id INT AUTO_INCREMENT PRIMARY KEY,

    usuario_id INT NOT NULL,

    fecha DATE NOT NULL,

    tipo VARCHAR(20) NOT NULL,

    FOREIGN KEY (usuario_id) REFERENCES usuario(id)

);


-- Tabla Horarios

CREATE TABLE Horarios (

    id INT AUTO_INCREMENT PRIMARY KEY,

    usuario_id INT NOT NULL,

    clase_id INT NOT NULL,

    FOREIGN KEY (usuario_id) REFERENCES usuario(id),

    FOREIGN KEY (clase_id) REFERENCES Clases(id)

);

ALTER TABLE alumnos ADD COLUMN estado ENUM('presente', 'ausente') DEFAULT 'presente';