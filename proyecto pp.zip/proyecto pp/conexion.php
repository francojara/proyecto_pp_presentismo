<?php
$server = "localhost";
$user = "root"; // Cambia esto si tienes un usuario diferente
$password = ""; // Cambia esto si tienes una contraseña
$base_de_datos = "colegio"; // Asegúrate de que este sea el nombre correcto de tu base de datos

$conexion = new mysqli($server, $user, $password, $base_de_datos);

if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}
?>